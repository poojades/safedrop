//
//  SafeDropTests.h
//  SafeDropTests
//
//  Created by Sankha Subhra Pathak on 8/1/13.
//  Copyright (c) 2013 Self. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>

@interface SafeDropTests : SenTestCase

@end
