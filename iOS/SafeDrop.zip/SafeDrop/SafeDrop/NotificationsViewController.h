//
//  NotificationsViewController.h
//  SafeDrop
//
//  Created by Sankha Subhra Pathak on 8/1/13.
//  Copyright (c) 2013 Self. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface NotificationsViewController : UIViewController

@end
