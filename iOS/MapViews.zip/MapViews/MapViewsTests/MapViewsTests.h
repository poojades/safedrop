//
//  MapViewsTests.h
//  MapViewsTests
//
//  Created by Sankha Subhra Pathak on 7/31/13.
//  Copyright (c) 2013 Self. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>

@interface MapViewsTests : SenTestCase

@end
