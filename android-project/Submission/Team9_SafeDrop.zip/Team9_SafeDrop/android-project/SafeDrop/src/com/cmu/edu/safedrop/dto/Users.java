
package com.cmu.edu.safedrop.dto;


public class Users{
   	private String econtact;
   	private String email;
   	private String ename;
   	private String firstname;
   	private String lastactive;
   	private String lastlat;
   	private String lastlong;
   	private String lastname;
   	private String mobile;
   	private String status;
   	private String zip;

 	public String getEcontact(){
		return this.econtact;
	}
	public void setEcontact(String econtact){
		this.econtact = econtact;
	}
 	public String getEmail(){
		return this.email;
	}
	public void setEmail(String email){
		this.email = email;
	}
 	public String getEname(){
		return this.ename;
	}
	public void setEname(String ename){
		this.ename = ename;
	}
 	public String getFirstname(){
		return this.firstname;
	}
	public void setFirstname(String firstname){
		this.firstname = firstname;
	}
 	public String getLastactive(){
		return this.lastactive;
	}
	public void setLastactive(String lastactive){
		this.lastactive = lastactive;
	}
 	public String getLastlat(){
		return this.lastlat;
	}
	public void setLastlat(String lastlat){
		this.lastlat = lastlat;
	}
 	public String getLastlong(){
		return this.lastlong;
	}
	public void setLastlong(String lastlong){
		this.lastlong = lastlong;
	}
 	public String getLastname(){
		return this.lastname;
	}
	public void setLastname(String lastname){
		this.lastname = lastname;
	}
 	public String getMobile(){
		return this.mobile;
	}
	public void setMobile(String mobile){
		this.mobile = mobile;
	}
 	public String getStatus(){
		return this.status;
	}
	public void setStatus(String status){
		this.status = status;
	}
 	public String getZip(){
		return this.zip;
	}
	public void setZip(String zip){
		this.zip = zip;
	}
}
