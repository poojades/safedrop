package com.cmu.edu.safedrop.dto;

public enum RequestStatus {
	New,
    Archived,
    Done,
    Cancel,
    Pending,
    InProgress,
    Accepted
}
