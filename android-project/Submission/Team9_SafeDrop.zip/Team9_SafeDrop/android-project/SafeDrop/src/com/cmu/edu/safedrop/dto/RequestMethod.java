package com.cmu.edu.safedrop.dto;

public enum RequestMethod {
	GET,
	POST
}
